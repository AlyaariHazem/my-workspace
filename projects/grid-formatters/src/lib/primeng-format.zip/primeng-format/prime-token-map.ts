// Angular DatePipe -> PrimeNG Calendar tokens
// PrimeNG: yy = 4-digit year, y = 2-digit year
//          MM = full month name, M = short month name
//          mm/m = numeric month, dd/d = day
export function ngToPrimeDate(fmt: string): string {
  if (!fmt) return 'dd/mm/yy';
  let out = fmt.trim();

  // 1) strip Angular literals and weekday tokens
  out = out.replace(/'[^']*'/g, '').trim(); // 'literal'
  out = out.replace(/E{1,4}/g, '').trim();  // E, EE, EEE, EEEE

  // --- SAFE PLACEHOLDERS (no M/Y sequences so later replacements won't touch them)
  const P_Y4  = '@@Y4@@';   // 4-digit year
  const P_Y2  = '@@Y2@@';   // 2-digit year
  const P_MF  = '@@MON_FULL@@';   // full month name (MMMM / LLLL)
  const P_MS  = '@@MON_SHORT@@';  // short month name (MMM / LLL)

  // 2) protect long tokens
  out = out
    .replace(/yyyy/g, P_Y4)
    .replace(/yy/g,   P_Y2)
    .replace(/LLLL/g, P_MF)
    .replace(/LLL/g,  P_MS)
    .replace(/MMMM/g, P_MF)
    .replace(/MMM/g,  P_MS);

  // 3) numeric month/day + single-year
  // Use lookarounds to only hit isolated single-letter tokens
  out = out
    .replace(/MM/g, 'mm')                         // 2-digit numeric month
    .replace(/(?<![A-Za-z])M(?![A-Za-z])/g, 'm')  // 1–2 digit numeric month
    .replace(/LL/g, 'mm')
    .replace(/(?<![A-Za-z])L(?![A-Za-z])/g, 'm')
    .replace(/dd/g, 'dd')
    .replace(/(?<![A-Za-z])d(?![A-Za-z])/g, 'd')
    // Angular single 'y' (full year) -> PrimeNG 4-digit 'yy'
    .replace(/(?<![A-Za-z])y(?![A-Za-z])/g, 'yy');

  // 4) restore placeholders -> PrimeNG name/year tokens
  out = out
    .replace(new RegExp(P_Y4, 'g'), 'yy')  // 4-digit year
    .replace(new RegExp(P_Y2, 'g'), 'y')   // 2-digit year
    .replace(new RegExp(P_MF, 'g'), 'MM')  // full month name
    .replace(new RegExp(P_MS, 'g'), 'M');  // short month name

  // 5) tidy punctuation/spacing
  out = out.replace(/\s*,\s*/g, ', ').replace(/\s{2,}/g, ' ').trim();

  return out || 'dd/mm/yy';
}

export function is12h(tf: string) {
  return /a+/.test(tf || '');
}
