import { Injectable, NgZone, OnDestroy } from '@angular/core';
import { BehaviorSubject } from 'rxjs';

export type UserFormats = { date: string; time: string; tz: string | null };

const LS_DATE_FMT_KEY = 'selectedDateFormat';
const LS_TIME_FMT_KEY = 'selectedDateTimeFormat';
const DEFAULT_DATE_FMT = 'yyyy-MM-dd';
const DEFAULT_TIME_FMT = 'HH:mm';
const DT_EVT = 'dt-format-changed';

@Injectable({ providedIn: 'root' })
export class DateFormatService implements OnDestroy {
  private _state = new BehaviorSubject<UserFormats>({
    date: localStorage.getItem(LS_DATE_FMT_KEY) || DEFAULT_DATE_FMT,
    time: localStorage.getItem(LS_TIME_FMT_KEY) || DEFAULT_TIME_FMT,
    tz: null,
  });
  readonly state$ = this._state.asObservable();

  private pollId: any;

  constructor(private zone: NgZone) {
    if (typeof window !== 'undefined') {
      window.addEventListener('storage', this.bump);
      window.addEventListener(DT_EVT, this.bump);
    }

    // 🔁 Same-tab fallback: detect LS changes even if no event is dispatched
    this.zone.runOutsideAngular(() => {
      this.pollId = setInterval(() => {
        const d = localStorage.getItem(LS_DATE_FMT_KEY) || DEFAULT_DATE_FMT;
        const t = localStorage.getItem(LS_TIME_FMT_KEY) || DEFAULT_TIME_FMT;
        const s = this._state.value;
        if (d !== s.date || t !== s.time) {
          this.zone.run(() => this._state.next({ ...s, date: d, time: t }));
        }
      }, 400);
    });
  }

  ngOnDestroy() {
    if (typeof window !== 'undefined') {
      window.removeEventListener('storage', this.bump);
      window.removeEventListener(DT_EVT, this.bump);
    }
    if (this.pollId) clearInterval(this.pollId);
  }

  private bump = () => {
    const s = this._state.value;
    this._state.next({
      date: localStorage.getItem(LS_DATE_FMT_KEY) || DEFAULT_DATE_FMT,
      time: localStorage.getItem(LS_TIME_FMT_KEY) || DEFAULT_TIME_FMT,
      tz: s.tz,
    });
  };

  /** Manual trigger if you change LS and want an immediate update */
  refreshFromLocalStorage() { this.bump(); }

  setTz(tz: string | null) { this._state.next({ ...this._state.value, tz }); }
  get snapshot() { return this._state.value; }
}
