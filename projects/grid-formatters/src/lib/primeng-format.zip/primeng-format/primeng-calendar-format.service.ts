// primeng-calendar-format.service.ts
import { Injectable, DestroyRef, inject } from '@angular/core';
import { PrimeNGConfig } from 'primeng/api';
import { map, shareReplay, distinctUntilChanged } from 'rxjs/operators';
import { DateFormatService } from './date-format.service';
import { ngToPrimeDate, is12h } from './prime-token-map';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';

@Injectable({ providedIn: 'root' })
export class PrimeCalendarFormatService {
  private readonly cfg = inject(PrimeNGConfig);
  private readonly fmt = inject(DateFormatService);
  private readonly destroyRef = inject(DestroyRef);

  /** PrimeNG-compatible date format (e.g. 'dd M yy' for 'dd MMM yyyy') */
  readonly dateFormat$ = this.fmt.state$.pipe(
    map(s => ngToPrimeDate(s.date)),
    distinctUntilChanged(),
    shareReplay({ bufferSize: 1, refCount: true })
  );

  /** '12' | '24' for PrimeNG calendars/timepickers */
  readonly hourFormat$ = this.fmt.state$.pipe(
    map(s => (is12h(s.time) ? '12' : '24') as '12' | '24'),
    distinctUntilChanged(),
    shareReplay({ bufferSize: 1, refCount: true })
  );

  // kept for backwards compat if you were already using it
  readonly primeDateFormat$ = this.dateFormat$;

  constructor() {
    // Set initial translation
    this.cfg.setTranslation({ dateFormat: ngToPrimeDate(this.fmt.snapshot.date) });

    // Keep PrimeNG i18n in sync with user changes
    this.dateFormat$
      .pipe(takeUntilDestroyed(this.destroyRef))
      .subscribe(df => {
        this.cfg.setTranslation({
          dateFormat: df,
          // you can add/merge more i18n keys here as needed:
          today: 'Today',
          clear: 'Clear',
        });
      });
  }
  
}
