// calendar-default-format.directive.ts
import { AfterViewInit, Directive, OnDestroy, inject } from '@angular/core';
import { Calendar } from 'primeng/calendar';
import { Subscription, fromEvent } from 'rxjs';
import { PrimeCalendarFormatService } from './primeng-calendar-format.service';

@Directive({
  selector: 'p-calendar',
  standalone: true,
})
export class CalendarDefaultFormatDirective implements AfterViewInit, OnDestroy {
  private cal = inject(Calendar);
  private fmt = inject(PrimeCalendarFormatService);
  private sub?: Subscription;
  private subHour?: Subscription;
  private stopObs?: () => void;
  private focusKillSub?: Subscription;

  private get input(): HTMLInputElement | null {
    return (this.cal as any).inputfieldViewChild?.nativeElement ?? null;
  }

  /** Remove any existing mask instance and its attributes */
  private removeMaskHard() {
    const el = this.input;
    if (!el) return;

    // PrimeNG wrapper helper (if present)
    try { (this.cal as any).destroyInputmask?.(); } catch {}

    // Underlying Inputmask lib instance
    try { (el as any).inputmask?.remove?.(); } catch {}

    // Remove attributes so it won't render placeholders
    el.removeAttribute('data-inputmask');
    el.removeAttribute('im-insert');
  }

  /** While month NAMES are used, prevent mask from (re)attaching */
  private blockFutureMask() {
    const el = this.input;
    if (!el) return;

    // Kill any new inputmask added by internal hooks
    const mo = new MutationObserver(() => {
      try { (el as any).inputmask?.remove?.(); } catch {}
      el.removeAttribute('data-inputmask');
      el.removeAttribute('im-insert');
    });
    mo.observe(el, { attributes: true, attributeFilter: ['data-inputmask', 'im-insert'] });
    this.stopObs = () => mo.disconnect();

    // Also remove on user focus (some versions init on focus)
    this.focusKillSub?.unsubscribe();
    this.focusKillSub = fromEvent(el, 'focus').subscribe(() => this.removeMaskHard());
  }

  private allowFutureMask() {
    this.stopObs?.(); this.stopObs = undefined;
    this.focusKillSub?.unsubscribe(); this.focusKillSub = undefined;
  }

  private apply(df: string) {
    const c: any = this.cal;

    // Always treat model as Date so formatting applies
    c.dataType = 'date';

    // PrimeNG tokens: M/MM = month NAMES, m/mm = numeric month
    const usesNameMonth = /(^|[^m])M/.test(df);

    // Apply the PrimeNG format
    c.dateFormat = df;

    if (usesNameMonth) {
      // Disable mask + purge any instance + prevent re-attach
      c.mask = false;            // if input exists in your version, this helps
      c.slotChar = ' ';
      this.removeMaskHard();
      this.blockFutureMask();
    } else {
      // Numeric formats: allow mask (optional), use space placeholders
      this.allowFutureMask();
      c.mask = true;
      c.slotChar = ' ';
      try { c.initInputMask?.(); } catch {}
    }

    // Force re-render of text in the input
    try { this.cal.updateInputfield(); } catch {}

    // One more microtask flush to catch late re-attaches
    queueMicrotask(() => {
      if (usesNameMonth) this.removeMaskHard();
      try { this.cal.updateInputfield(); } catch {}
    });
  }

  ngAfterViewInit() {
    // defer so inner input exists
    queueMicrotask(() => {
      this.sub = this.fmt.dateFormat$.subscribe(df => this.apply(df));
      this.subHour = this.fmt.hourFormat$.subscribe(h => {
        (this.cal as any).hourFormat = h; // '12' | '24'
        try { this.cal.updateInputfield(); } catch {}
      });

      // OPTIONAL: debug line — should print once per calendar
      // console.debug('[CalendarFormat] attached', this.cal);
    });
  }

  ngOnDestroy() {
    this.sub?.unsubscribe();
    this.subHour?.unsubscribe();
    this.allowFutureMask();
  }
}
